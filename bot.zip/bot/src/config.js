import "dotenv/config";

/**
 * Turns a sloppily-written ping into a real Discord mention.
 *   "@&123"  -> "<@&123>"   (angle brackets forgotten)
 *   "123"    -> "<@&123>"   (bare role ID pasted in)
 *   "<@&123>", "@here", "@everyone" -> unchanged (already valid)
 * Empty/unset -> null (no ping at all, the default).
 */
function normalisePingMessage(raw) {
    const value = (raw || "").trim();
    if (!value) return null;
    if (/^@&\d+$/.test(value))  return `<@&${value.slice(2)}>`;
    if (/^\d{15,25}$/.test(value)) return `<@&${value}>`;
    return value;
}

export const CONFIG = {
    TOKEN:          process.env.DISCORD_BOT_TOKEN,
    CLIENT_ID:      process.env.DISCORD_CLIENT_ID,
    GUILD_ID:       process.env.DISCORD_GUILD_ID       || null,
    LOG_CHANNEL_ID: process.env.DISCORD_LOG_CHANNEL_ID || null,
    // MySQL / MariaDB — either a mysql://user:password@host:3306/dbname URL,
    // or the separate DB_* variables below (DB_HOST wins if both are set).
    DATABASE_URL:   process.env.DATABASE_URL,
    DB: {
        // DB_HOST may be written "host" or "host:3306" — the port is split off either way.
        HOST:     (process.env.DB_HOST || "").trim().replace(/:\d+$/, "") || null,
        PORT:     parseInt((process.env.DB_HOST || "").trim().match(/:(\d+)$/)?.[1], 10) || parseInt(process.env.DB_PORT, 10) || 3306,
        USER:     process.env.DB_USER     || null,
        PASSWORD: process.env.DB_PASSWORD || "",
        NAME:     process.env.DB_NAME     || null,
    },
    STAFF_SECRET:   process.env.STAFF_SECRET,
    API_BASE:       (process.env.API_BASE || "https://snaptech.vercel.app").replace(/\/$/, ""),

    // Optional ping sent with every new-request message (e.g. "@here" or a role
    // mention like "<@&123456789>"). Left unset by default — pinging @everyone
    // on every single request floods the channel and staff phones under load.
    // Set DISCORD_PING_MESSAGE in .env if you want a ping.
    //
    // Normalised on the way in: a role ID written without its angle brackets
    // ("@&123", or a bare "123456789") is NOT a Discord mention — it renders
    // as literal text and pings nobody, which looks identical in the config
    // log to a working one. Repairing it here turns a silent no-ping into a
    // working ping instead of a bug nobody notices for weeks.
    PING_MESSAGE:   normalisePingMessage(process.env.DISCORD_PING_MESSAGE),

    // Role pinged on brand-new requests (before anyone claims them).
    ACCESS_ROLE_ID: process.env.ACCESS_ROLE_ID || "1546160211054559334",

    // ─── Permissions ────────────────────────────────────────────────────
    // OWNER: full access to everything — every command, every button on
    // every request regardless of who claimed it. Bypasses the
    // claimer-only lock entirely.
    OWNER_ROLE_ID: process.env.OWNER_ROLE_ID || "1545903998442405970",
    // STAFF: required to run any slash command or click any request
    // button at all. Defaults to the same role as ACCESS_ROLE_ID (the
    // role already pinged on new requests) since that's who's meant to
    // be working requests, but kept as a separate setting in case they
    // ever diverge.
    STAFF_ROLE_ID: process.env.STAFF_ROLE_ID || "1546160211054559334",

    // Channel where the personal staff-settings panel (language, ping
    // preference, etc.) is posted. Each staff member configures only
    // their own preferences there — never the bot's global config.
    STAFF_CONFIG_CHANNEL_ID: process.env.STAFF_CONFIG_CHANNEL_ID || "1550994704018046976",

    // ─── Web staff panel ───────────────────────────────────────────────────────
    // Started from bot.js itself (see src/web/server.js) so it lives on the
    // exact same host/process as the bot — required since it must be
    // reachable at Snaptech.sub-yorkhost.fr, which is this bot's own hosting.
    WEB_ENABLED:        process.env.WEB_ENABLED !== "0", // set WEB_ENABLED=0 to disable entirely
    WEB_PORT:           parseInt(process.env.WEB_PORT, 10) || 25021,
    WEB_HOST:           process.env.WEB_HOST || "0.0.0.0",
    // A pending request older than this drops off the "Unclaimed" queue on
    // the web dashboard — it's presumably dead/abandoned by then and just
    // clutters the view. Purely a display filter: the row itself, and
    // Discord's own channel message, are untouched — claiming it from
    // Discord (or the DB directly) still works exactly as before.
    UNCLAIMED_MAX_AGE_MINUTES: parseInt(process.env.UNCLAIMED_MAX_AGE_MINUTES, 10) || 20,
    // Public URL staff actually use — needed to build the Discord OAuth2
    // redirect URI correctly (must match EXACTLY what's registered in the
    // Discord Developer Portal, protocol included).
    WEB_BASE_URL:       (process.env.WEB_BASE_URL || "https://Snaptech.sub-yorkhost.fr").replace(/\/$/, ""),
    // OAuth2 client secret — NOT the bot token. From the Discord Developer
    // Portal, same application, "OAuth2" tab — General → Client Secret.
    DISCORD_CLIENT_SECRET: process.env.DISCORD_CLIENT_SECRET || null,
    // Signs the login session cookie. Auto-generated on first boot if unset
    // and printed once — copy it into .env so sessions survive a restart
    // (otherwise everyone gets logged out every time the bot redeploys).
    WEB_SESSION_SECRET: process.env.WEB_SESSION_SECRET || null,

    // Per-operator channel routing — falls back to LOG_CHANNEL_ID if unset.
    // "belgium" groups BASE, Orange Belgium, Proximus and Telenet into one channel.
    CHANNELS: {
        orange:   process.env.CHANNEL_ORANGE_ID   || null,
        sfr:      process.env.CHANNEL_SFR_ID      || null,
        bouygues: process.env.CHANNEL_BOUYGUES_ID || null,
        belgium:  process.env.CHANNEL_BELGIUM_ID  || null,
    },
    // Hour (0-23, server/UTC time) at which the optional personal "daily
    // summary" DM is sent to staff who opted in. No per-user timezone is
    // tracked, so this is one shared hour for everyone — default 20 (8 PM UTC).
    DAILY_SUMMARY_HOUR_UTC: Number.isFinite(parseInt(process.env.DAILY_SUMMARY_HOUR_UTC, 10))
        ? parseInt(process.env.DAILY_SUMMARY_HOUR_UTC, 10)
        : 20,
};

// Belgian carriers all route to the single "belgium" channel.
const BELGIAN_OPERATORS = ["base", "orange_be", "proximus", "telenet"];

// The set of "operator groups" the bot actually distinguishes anywhere
// (channel routing, per-staff DM-alert filtering). Deliberately the same
// four buckets as CHANNELS above, plus "other" for anything unrecognised —
// there is no finer-grained grouping anywhere else in the bot, so exposing
// more detail in a filter UI would offer choices that don't correspond to
// any real distinction the bot makes.
export const OPERATOR_GROUPS = ["orange", "sfr", "bouygues", "belgium", "other"];

/** Which group a raw carrier code (row.operator) belongs to. */
export function getOperatorGroup(operator) {
    const op = operator?.toLowerCase();
    if (BELGIAN_OPERATORS.includes(op)) return "belgium";
    if (op === "orange" || op === "sfr" || op === "bouygues") return op;
    return "other";
}

/**
 * Resolve which Discord channel ID a given carrier should post to.
 * Falls back to CONFIG.LOG_CHANNEL_ID if no dedicated channel is configured.
 */
export function getChannelIdForOperator(operator) {
    const group = getOperatorGroup(operator);
    if (group === "other") return CONFIG.LOG_CHANNEL_ID;
    return CONFIG.CHANNELS[group] || CONFIG.LOG_CHANNEL_ID;
}

export function validateConfig() {
    // Hard required — bot cannot start without these
    const required = ["TOKEN", "CLIENT_ID", "STAFF_SECRET"];
    const missing = required.filter(k => !CONFIG[k]);
    const hasDbParts = CONFIG.DB.HOST && CONFIG.DB.USER && CONFIG.DB.NAME;
    if (!CONFIG.DATABASE_URL && !hasDbParts) missing.push("DATABASE_URL (or DB_HOST + DB_USER + DB_NAME)");
    if (missing.length > 0) {
        console.error("❌ Missing required env variables:", missing.join(", "));
        process.exit(1);
    }

    // Soft required — bot starts but features are degraded
    if (!CONFIG.LOG_CHANNEL_ID) {
        console.warn("⚠️  DISCORD_LOG_CHANNEL_ID not set — run /config in Discord to set it");
    }
    if (!CONFIG.GUILD_ID) {
        console.warn("⚠️  DISCORD_GUILD_ID not set — slash commands will deploy globally (up to 1h delay)");
    }

    console.log("✅ Config loaded");
    console.log("   API_BASE       :", CONFIG.API_BASE);
    console.log("   Database       :", CONFIG.DB.HOST ? `${CONFIG.DB.HOST}:${CONFIG.DB.PORT}/${CONFIG.DB.NAME}` : "DATABASE_URL (mysql)");
    console.log("   Default channel:", CONFIG.LOG_CHANNEL_ID     || "(not set)");
    console.log("   Orange channel :", CONFIG.CHANNELS.orange    || "(uses default)");
    console.log("   SFR channel    :", CONFIG.CHANNELS.sfr       || "(uses default)");
    console.log("   Bouygues chan. :", CONFIG.CHANNELS.bouygues  || "(uses default)");
    console.log("   Belgium channel:", CONFIG.CHANNELS.belgium   || "(uses default)");
    console.log("   Guild ID       :", CONFIG.GUILD_ID           || "(global)");
    console.log("   Ping message   :", CONFIG.PING_MESSAGE       || "(none — set DISCORD_PING_MESSAGE to enable)");
    console.log("   Owner role     :", CONFIG.OWNER_ROLE_ID);
    console.log("   Acces role     :", CONFIG.STAFF_ROLE_ID);
    console.log("   Acces cfg chan.:", CONFIG.STAFF_CONFIG_CHANNEL_ID || "(not set)");

    if (CONFIG.WEB_ENABLED) {
        console.log("   Web panel      :", `${CONFIG.WEB_BASE_URL} (listening on ${CONFIG.WEB_HOST}:${CONFIG.WEB_PORT})`);
        if (!CONFIG.DISCORD_CLIENT_SECRET) {
            console.warn("⚠️  DISCORD_CLIENT_SECRET not set — the web panel's Discord login will fail. Get it from the Developer Portal → OAuth2 → Client Secret.");
        }
    } else {
        console.log("   Web panel      : disabled (WEB_ENABLED=0)");
    }
}
